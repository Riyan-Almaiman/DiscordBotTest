const getOpenAIResponse = require("./openai");

module.exports = (client) => {
  client.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    // Handling for "hey" command
    if (interaction.commandName === "hey") {
      try {
        await interaction.reply("Hey!");
      } catch (error) {
        console.error("Error in 'hey' command:", error);
      }
      return; // Exit to avoid handling other commands
    }

    // Handling for "chat" command
    if (interaction.commandName === "chat") {
      const userMessage = interaction.options.getString("message");

      try {
        await interaction.deferReply();
        const replyText = await getOpenAIResponse(userMessage);
        const response = replyText.length > 2000 ? replyText.substring(0, 1997) + "..." : replyText;
        await interaction.followUp(response);
      } catch (error) {
        console.error("Error in 'chat' command:", error);
        if (!interaction.deferred && !interaction.replied) {
          await interaction.reply("Sorry, I couldn't process your request.").catch(console.error);
        } else {
          await interaction.followUp("Sorry, I couldn't process your request.").catch(console.error);
        }
      }
    }
  });
};
